export default {
   name: ['sc'],
   command: ['sc', 'source', 'script'],
   tags: 'other',
   run: async (m, { sock }) => {
      const message = `Berikut source code bot ini, silakan dikembangkan lebih lanjut.\n\n` +
         `- *Link* : \n` +
         `- *Creator* : Foxstore\n` +
         `- *Credits* : Luthfi Joestars\n\n`+
         `Jangan lupa kasih ⭐ di repository :D`
      sock.reply(m.from, message, m)
   },
   owner: false
}
