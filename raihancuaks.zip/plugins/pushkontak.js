export default {
  name: ['pushkontak'],
  command: ['pushkontak'],
  tags: 'main',
  owner: true,
  run: async (m, { sock, text, example }) => {
    try {
      if (!text.includes('|')) {
        return m.reply(example('pushkontak id|jeda|pesan'));
      }

      const args = text.split('|');
      const groupId = args[0]?.trim();
      const delay = parseInt(args[1]?.trim()) || 5000;
      const pesan = args.slice(2).join('|').trim();

      if (!groupId.endsWith('@g.us') || !pesan) {
        return m.reply(example('pushkontak id|jeda|pesan'));
      }

      const groupMetadata = await sock.groupMetadata(groupId);
      const participants = groupMetadata.participants;

      m.reply(`Mulai push kontak ke ${participants.length} anggota *${groupMetadata.subject}* dengan jeda ${delay / 1000} detik...\nAnti kenon aktif.`);

      let count = 0;
      for (let i = 0; i < participants.length; i++) {
        const member = participants[i];
        const jid = member.id;

        if (jid === sock.user.id) {
          continue;
        }

        const isAdmin = groupMetadata.participants.find(p => p.id === jid && (p.admin === 'admin' || p.admin === 'superadmin'));
        if (isAdmin) continue;

        setTimeout(async () => {
          try {
            const chatExists = await sock.onWhatsApp(jid);
            if (!chatExists?.[0]?.exists) {
              console.log(`Skip ${jid} (tidak pernah chat / kenon)`);
              return;
            }

            await new Promise(r => setTimeout(r, 1500));
            await sock.sendMessage(jid, { text: pesan });

            console.log(`Terkirim ke: ${jid}`);
          } catch (err) {
            console.log(`Gagal kirim ke ${jid}:`, err.message);
          }

          count++;
          if (count >= participants.length) {
            m.reply('Push kontak selesai!');
          }
        }, i * delay);
      }

    } catch (err) {
      console.error(err);
      m.reply('Terjadi kesalahan saat push kontak.\nPastikan ID grup valid dan bot masih tergabung.');
    }
  }
};
