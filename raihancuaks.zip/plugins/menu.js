export default {
  name: 'menu',
  command: ['menu'],
  tags: 'other',
  run: async (m, { sock, plugins }) => {
    try {
      // Kategorikan per command
      const categories = Object.values(plugins).reduce((acc, plugin) => {
        if (!plugin.tags) return acc;
        const names = Array.isArray(plugin.name) ? plugin.name : [plugin.name];
        acc[plugin.tags] = acc[plugin.tags] || new Set();
        names.forEach(name => acc[plugin.tags].add(name));
        return acc;
      }, {});

      // Buat teks menunya
      const menuText = "Halo! Berikut adalah daftar menu yang tersedia:\n\n" +
        Object.entries(categories)
          .sort()
          .map(([tag, cmds]) => {
            const lines = [...cmds]
              .sort()
              .map((cmd, idx, arr) => ` ${idx === arr.length - 1 ? '└' : '├'} ${cmd}`);
            return `🔹 \`${tag.toUpperCase()}\`\n${lines.join('\n')}`;
          }).join('\n\n');

      // Kirim menu dengan externalAdReply (thumbnailUrl harus direct link)
      m.reply({
        text: menuText.trim(),
        contextInfo: {
            mentionedJid: sock.parseMentions(menuText),
            isForwarded: true,
            forwardingScore: 999,
            externalAdReply: {              
               thumbnailUrl: 'https://files.catbox.moe/3zhk5b.jpg', // Valid direct image
                title: `Hi, ${m.pushName}`,
                body: '© Foxstore',
                renderLargerThumbnail: true,
                mediaType: 1
            },
         },
      });

    } catch (err) {
      console.error('Menu error:', err);
      m.reply('Gagal menampilkan menu.');
    }
  }
};
