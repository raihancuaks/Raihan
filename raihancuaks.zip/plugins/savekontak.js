import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: ['savekontak'],
    command: ['simpankontak', 'save', 'savecontact'],
    tags: 'main',
    owner: true,
    run: async (m, { sock, text, setting, example }) => {
        try {
            if (!text.endsWith('@g.us')) {
                return m.reply(example('save <idgroup>'));
            }

            const groupId = text.trim();
            const groupMetadata = await sock.groupMetadata(groupId);
            const participants = groupMetadata.participants;

            const botJid = sock.user.id;

            const filtered = participants.filter(p => p.id !== botJid);

            if (filtered.length === 0) {
                return m.reply('Tidak ada member dalam grup selain bot.');
            }

            let vcfContent = '';
            filtered.forEach((member, index) => {
                const number = member.id.split('@')[0];
                vcfContent += `BEGIN:VCARD\nVERSION:3.0\nFN:${setting.kontak} ${index + 1}\nTEL;type=CELL:+${number}\nEND:VCARD\n\n`;
            });

            const dirPath = path.join(__dirname, '../temp');
            if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });

            const safeName = groupMetadata.subject.replace(/[^a-zA-Z0-9]/g, '_');
            const fileName = `${safeName}.vcf`;
            const filePath = path.join(dirPath, fileName);

            fs.writeFileSync(filePath, vcfContent);

            let msg = await sock.sendMessage(m.from, {
                document: { url: filePath },
                fileName,
                mimetype: 'text/x-vcard'
            }, { quoted: m });

            await sock.sendMessage(m.from, {
                text: 'Silakan',
            }, { quoted: msg });

            fs.unlinkSync(filePath);

        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat menyimpan kontak:\n' + err.message);
        }
    }
};
