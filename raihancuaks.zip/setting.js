export default {
   "owner": "6285372277748",
   "kontak": "buyer fox",
   "anticall": true,
   "readsw": false,
   "reactsw": false,
   "readchat": false,
   "autotyping": true,
   "self": false,
   "online": false,
   "prefix": true,
   "blacklist": [],
   "emoji": [
      "❤️",
      "💛",
      "💚",
      "💙",
      "💜"
   ],
   "pairing": {
      "state": true,
      "number": 62812345778
   }
}
