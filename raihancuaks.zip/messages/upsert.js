import { msg, example } from "../lib/simple.js";
import setting from '../setting.js';
import chalk from 'chalk';

export async function message(sock, m, plugins, store) {
    m = await msg(sock, m);
    try {
        const prefixes = ["!", ".", "#", "/"];
        const hasPrefix = prefixes.some((p) => m.body.startsWith(p));

        const isCmd = setting.prefix ? hasPrefix : true;
        const prefix = hasPrefix ? prefixes.find((p) => m.body.startsWith(p)) || "" : "";

        const command = m.body
            .slice(prefix.length)
            .toLowerCase()
            .trim()
            .split(/\s+/)[0] || "";

        const args = m.body.trim().split(/\s+/).slice(1);
        const text = args.join(" ");
        const isOwner = m.key.fromMe || m.sender === `${setting.owner}@s.whatsapp.net`;

        if (setting.autotyping) sock.sendPresenceUpdate('composing', m.from);
        if (!setting.online) sock.sendPresenceUpdate('unavailable', m.from);
        if (setting.online) sock.sendPresenceUpdate('available', m.from);
        if (setting.readchat) sock.readMessages([m.key]);

        if (!m.from.endsWith('newsletter') && !/protocol/.test(m.type)) {
            console.log(
                `--------------------------------------------------
  ${chalk.blue("from")}: ${chalk.yellow(m.pushName + " > " + m.sender)}
  ${chalk.blue("in")}: ${chalk.magenta(m.isGroup ? "👥 Group" : "👤 Private")}
  ${chalk.blue("message")}: ${chalk.green(m.body || m.type)}
  ${chalk.blue("type")}: ${chalk.cyan(m.type)}
  ${chalk.blue("time")}: ${chalk.red(new Date().toLocaleTimeString())}
  --------------------------------------------------`
            );
        }

        if (setting.self && !isOwner) return;

        for (const name in plugins) {
            const cmd = plugins[name];
            const isCommand = cmd.command.includes(command);
            const isValidCommand = (cmd.noPrefix || isCmd) && isCommand;
           
            if (cmd.owner && !isOwner) continue;
            if (cmd.private && m.isGroup) continue;
            if (isValidCommand) {
                sock.readMessages([m.key]);
            }
            if ((cmd.noPrefix || isCmd) && isCommand) {
                if (cmd.owner && !isOwner) {
                    m.reply('Fitur ini hanya untuk owner');
                    continue;
                }
                if (cmd.wait) await sock.sendMessage(m.from, { react: { text: '🕒', key: m.key }});

                cmd.run(m, {
                    sock,
                    q: m.isQuoted ? m.quoted : m,
                    plugins,
                    command,
                    example,
                    setting,
                    store,
                    text,
                });
            }
        }
    } catch (e) {
        console.error(e);
    }
}
